from axpa_core import main


if __name__ == "__main__":
    raise SystemExit(main(["pack", *(__import__("sys").argv[1:])]))
